﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataGenerator
{
    public class EventHubElement
    {
        public string EventHubName
        {
            get; set;
        }


        public string ConnectionString
        {
            get; set;
        }


        public string Region
        {
            get; set;
        }
    }
}
