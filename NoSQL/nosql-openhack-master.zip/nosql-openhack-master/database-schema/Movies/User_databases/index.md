#### 

[Project](../../index.md) > [Movies SQL Server](../index.md) > User databases

# ![User](../../Images/folder32.png) User databases

---

## <a name="#databases"></a>Databases (1)

* ![Database](../../Images/Database.png) [Movies](Movies/index.md)


---

###### Author:  Contoso Video, Ltd.

###### Copyright 2020 - All Rights Reserved

###### Created: 2020/01/03

