#### 

[Project](../../../index.md) > [Movies SQL Server](../../index.md) > [User databases](../index.md) > Movies

# ![Database](../../../Images/ntDatabase.png) Movies Database

---

## <a name="#objecttypes"></a>Object Types

* ![Tables](../../../Images/Table.png) [Tables](Tables/Tables.md)


---

## <a name="#dbproperties"></a>Database Properties

| Property | Value |
|---|---|
| SQL Server Version | Azure Sql Database |
| Compatibility Level | SQL Server 2017 |


---

###### Author:  Contoso Video, Ltd.

###### Copyright 2020 - All Rights Reserved

###### Created: 2020/01/03

