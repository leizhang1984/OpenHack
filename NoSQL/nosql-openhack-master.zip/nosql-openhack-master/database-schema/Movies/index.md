#### 

[Project](../index.md) > Contoso Video SQL Server documentation

# ![Server](../Images/ntServer.png) Contoso Video SQL Server documentation

---

## <a name="#databases"></a>Databases (1)

* ![Database](../Images/Database.png) [Movies](User_databases/Movies/index.md)


---

## <a name="#serverproperties"></a>Server Properties

| Property | Value |
|---|---|
| Edition | SQL Azure |


---

###### Author:  Contoso Video, Ltd.

###### Copyright 2020 - All Rights Reserved

###### Created: 2020/01/03

