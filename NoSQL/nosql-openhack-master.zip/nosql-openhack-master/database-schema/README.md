# Contoso Video SQL Server documentation

Contoso Video has provided the following documentation for the Movie catalog SQL Server database.

[**Read the documentation**](Movies/index.md)

Database ER diagram:

![Database ER diagram](database-diagram.png)

###### Author:  Contoso Video, Ltd.

###### Copyright 2020 - All Rights Reserved

###### Created: 2020/01/03

