﻿using Contoso.Apps.Movies.Data.Models;

namespace Contoso.Apps.Movies.Web.Models
{
    public class ProductModel : Item
    {
        public string CategoryCategoryName { get; set; }
    }
}